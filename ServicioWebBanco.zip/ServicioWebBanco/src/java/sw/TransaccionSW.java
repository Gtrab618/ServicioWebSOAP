/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sw;

import java.util.ArrayList;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import modelo.Operacion;
import modelo.Usuario;

/**
 *
 * @author Usuario
 */
@WebService(serviceName = "TransaccionSW")
public class TransaccionSW {

    private ArrayList<Usuario> arrayUsu = new ArrayList<>();

    @WebMethod(operationName = "registrar")
    public boolean registrar(@WebParam(name = "usuario") Usuario usu) {

        return arrayUsu.add(usu);

    }

    @WebMethod(operationName = "logeo")
    public Usuario login(@WebParam(name = "usuario") Usuario usu) {
        Usuario user = new Usuario();

        for (int i = 0; i < arrayUsu.size(); i++) {

            if (arrayUsu.get(i).getNombre().equals(usu.getNombre()) && arrayUsu.get(i).getClave().equals(usu.getClave())) {

                user = arrayUsu.get(i);
                break;
            }

        }
       
        return user;
    }

    @WebMethod(operationName = "depositar")
    public Operacion depositar(@WebParam(name = "cantidad") Operacion ope) {
        Operacion depo = new Operacion();
        for (int i = 0; i < arrayUsu.size(); i++) {

            if (arrayUsu.get(i).getNombre().equals(ope.getUsuario())) {

                depo.setExito(true);
                arrayUsu.get(i).setSaldo(arrayUsu.get(i).getSaldo() + ope.getSaldo());
                depo.setSaldo(arrayUsu.get(i).getSaldo());
                depo.setUsuario(arrayUsu.get(i).getNombre());
                break;
            }

        }
        return depo;
    }

    @WebMethod(operationName = "retirar")
    public Operacion retirar(@WebParam(name = "cantidad") Operacion ope) {
        Operacion depo = new Operacion();
        for (int i = 0; i < arrayUsu.size(); i++) {

            if (arrayUsu.get(i).getNombre().equals(ope.getUsuario())) {

                if (arrayUsu.get(i).getSaldo() > ope.getSaldo()) {
                    depo.setExito(true);
                    arrayUsu.get(i).setSaldo(arrayUsu.get(i).getSaldo() - ope.getSaldo());
                    depo.setSaldo(arrayUsu.get(i).getSaldo());
                    depo.setUsuario(arrayUsu.get(i).getNombre());
                    break;
                } else {
                    depo.setExito(false);
                    depo.setSaldo(arrayUsu.get(i).getSaldo());
                    depo.setUsuario(ope.getUsuario());
                }
            }

        }
        return depo;
    }
}
