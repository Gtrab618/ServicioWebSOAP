/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.Color;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JOptionPane;
import sw.Operacion;
import sw.TransaccionSW;
import sw.TransaccionSW_Service;
import sw.Usuario;
import vista.Interfaz;

/**
 *
 * @author Usuario
 */
public class Control {

    private Interfaz vInter;

    private TransaccionSW_Service servicio = new TransaccionSW_Service();
    private TransaccionSW trans = servicio.getTransaccionSWPort();
    private Usuario usuSW;
    private Operacion opeSW;

    public Control(Interfaz vInter, Usuario usuSW, Operacion opeSW) {
        this.opeSW = opeSW;
        this.usuSW = usuSW;
        this.vInter = vInter;

        vInter.setVisible(true);
        referenciarObjetos();
    }

    public void iniciarControl() {
        vInter.getBtnRegUsu().addActionListener(l -> irPanelRegistro());
        vInter.getBtn_ValiRegUsu().addActionListener(l -> verificarRegistro());
        vInter.getBtnIngre().addActionListener(l -> login());
        vInter.getBtnRegOpe().addActionListener(l -> registrarOperaciones());
        vInter.getBtnSalir().addActionListener(l->irPanelInicio());
    }

    private void referenciarObjetos() {
        vInter.getPnlRegistro().setVisible(false);
        vInter.getPnlOperaciones().setVisible(false);
        vInter.getLblAlertInic().setVisible(false);
    }

    private void irPanelRegistro() {
        vInter.getPnlRegistro().setVisible(true);
        vInter.getPnlInicio().setVisible(false);
        vInter.getTxtPass2Reg().setText("");
        vInter.getTxtPassReg().setText("");
        vInter.getTxtUserReg().setText("");
        vInter.getLblAlerReg().setVisible(false);

    }

    private void irPanelInicio() {
        vInter.getPnlRegistro().setVisible(false);
        vInter.getPnlOperaciones().setVisible(false);
        vInter.getPnlInicio().setVisible(true);
        vInter.getTxtUser().setText("");
        vInter.getTxtPass().setText("");
        vInter.getLblAlertInic().setVisible(false);

    }

    private void irPanelOperaciones() {
        vInter.getLblAlertOpera().setText("");
        vInter.getPnlRegistro().setVisible(false);
        vInter.getPnlOperaciones().setVisible(true);
        vInter.getPnlInicio().setVisible(false);
        vInter.getLblAlertOpeUsu().setText(usuSW.getNombre());
        vInter.getLblAlertOpeSal().setText(usuSW.getSaldo() + "");

    }
    
    

    private void verificarRegistro() {
        String usuario = "";
        String pass = "";
        String pass2 = "";

        usuario = vInter.getTxtUserReg().getText().trim();
        pass = vInter.getTxtPassReg().getText().trim();
        pass2 = vInter.getTxtPass2Reg().getText().trim();

        if (usuario.equals("") || pass.equals("") || pass2.equals("")) {
            JOptionPane.showMessageDialog(null, "Llene todos los campos");

        } else {
            if (pass.equals(pass2)) {
                usuSW.setNombre(usuario);
                usuSW.setClave(pass2);
                usuSW.setSaldo(100);

                if (trans.registrar(usuSW)) {

                    vInter.getLblAlerReg().setVisible(true);

                    //crear un timertask para mostrar que fue registrado exitosamente
                    Timer timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {

                            irPanelInicio();
                        }
                    }, 1500);

                } else {
                    JOptionPane.showMessageDialog(null, "Error al registrar");
                }

            } else {
                JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden");
            }

        }

    }

    private void login() {
        vInter.getLblAlertInic().setVisible(false);
        String user = "";

        user = vInter.getTxtUser().getText().trim();
        char clave[] = vInter.getTxtPass().getPassword();
        String clavedef = new String(clave);
        usuSW.setNombre(user);
        usuSW.setClave(clavedef);

        usuSW = trans.logeo(usuSW);

        if (usuSW.getNombre() == null) {

            vInter.getLblAlertInic().setVisible(true);
        } else {

            irPanelOperaciones();
        }
    }

    private void registrarOperaciones() {
        int saldo = Integer.parseInt(vInter.getSpnCantidad().getValue().toString());
        
        //realizar retiros
        if (vInter.getRdbRetiro().isSelected()) {
            opeSW.setSaldo(saldo);
            opeSW.setUsuario(usuSW.getNombre());

            opeSW = trans.retirar(opeSW);
      

            if (opeSW.isExito()) {
                vInter.getLblAlertOpera().setText("Operación exitosa");
                vInter.getLblAlertOpera().setForeground(Color.GREEN);
                vInter.getLblAlertOpeSal().setText(opeSW.getSaldo() + "");
            } else {
                vInter.getLblAlertOpera().setText("Saldo insuficiente");
                vInter.getLblAlertOpera().setForeground(Color.RED);
            }
        } else {
            //realizar depositos
            opeSW.setSaldo(saldo);
            opeSW.setUsuario(usuSW.getNombre());
            opeSW=trans.depositar(opeSW);
             System.out.println(opeSW.getSaldo()+"Depo");
            if(opeSW.isExito()){
                vInter.getLblAlertOpera().setText("Operación exitosa");
                vInter.getLblAlertOpera().setForeground(Color.GREEN);
                vInter.getLblAlertOpeSal().setText(opeSW.getSaldo() + "");
            }else{
                
                JOptionPane.showMessageDialog(null, "erro al depositar");
            }
        }

    }
}
