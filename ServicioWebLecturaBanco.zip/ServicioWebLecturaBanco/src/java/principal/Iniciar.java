/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import control.Control;
import sw.Operacion;
import sw.Usuario;

import vista.Interfaz;

/**
 *
 * @author Usuario
 */
public class Iniciar {

    public static void main(String[] args) {

        Interfaz inter = new Interfaz();
        Usuario usuSW = new Usuario();
        Operacion opeSW = new Operacion();
        Control cnt = new Control(inter,usuSW,opeSW);

        cnt.iniciarControl();
    }
}
